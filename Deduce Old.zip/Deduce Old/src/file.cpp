/*
 * file.c
 *
 *  Created on: Nov 1, 2020
 *      Author: wade4
 */
#include "deduce.h"

HANDLE openVolume(TCHAR *VolumeName) {
    DWORD read;

    HANDLE VolumeHandle = CreateFile(VolumeName, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_FLAG_NO_BUFFERING, NULL);
    if (VolumeHandle == INVALID_HANDLE_VALUE) {
        exitWithLastError(_T("Failed opening the volume '%s'\n"), VolumeName);
    }
    return VolumeHandle;
}

LONGLONG seek(HANDLE fileHandle, LONGLONG distance, DWORD MoveMethod) {
    LARGE_INTEGER li;
    li.QuadPart = distance;
    li.LowPart = SetFilePointer(fileHandle, li.LowPart, &li.HighPart, MoveMethod);
    if (li.LowPart == INVALID_SET_FILE_POINTER && GetLastError() != NO_ERROR) {
        li.QuadPart = -1;
    }

    return li.QuadPart;
}

